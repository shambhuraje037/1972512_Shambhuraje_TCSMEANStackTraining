// let rec = require("./records")

// //rec.clearRecord() // clear all entries from record

let obj = require('./records')          
obj.logRecord()