export class Task{
    constructor(public id:string, public name:string, public task:string, public deadline:Date){}
}